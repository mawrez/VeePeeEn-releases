VeePeeEn 1.3.0 - free v2ray subscription mass-tester + VPN, with a separate OpenVPN section (Windows x64)
=========================================================================================================

WHAT'S IN THE ZIP
  VeePeeEn.exe     the app
  sing-box.exe     official SagerNet sing-box 1.14.4 (windows-amd64) - the proxy core
  libcronet.dll    shipped with the official sing-box release (only used by "naive" proxies)
  openvpn\         official OpenVPN 2.6.23 (openvpn.exe, OpenSSL DLLs, tapctl.exe) plus the
                   Microsoft-signed tap-windows6 9.27 and ovpn-dco driver packages (OpenVPN section)
  README.txt       this file
Keep all files (and the openvpn folder) in the same folder.

INSTALLER (recommended)
  VeePeeEn-<version>-setup.exe installs to %LOCALAPPDATA%\Programs\VeePeeEn (no admin
  needed to install), adds Start Menu + Desktop shortcuts (right-click -> Pin to taskbar) and an
  uninstaller (Settings -> Apps). Installed copies update themselves: an "Update" button appears
  in the header when a new version is out; nothing downloads until you click it.
  This zip is the portable version (no auto-update).

RUNNING (as administrator)
  1. Unzip anywhere (e.g. C:\Tools\VeePeeEn). Do not run it from inside the zip.
  2. Double-click VeePeeEn.exe. It asks for administrator rights (UAC) because
     TUN mode creates a virtual network adapter (wintun, built into sing-box.exe).
     If you decline UAC it still opens; Proxy mode works, TUN mode does not.
  3. The app opens in the small COMPACT SWITCHER: big connect button, current
     server with latency + Clean score, TUN/Proxy toggle and a list of the best
     servers - click one to switch. "Test all" runs the tester from there too.
     The arrows button (top right) expands to the full dashboard; "Compact view"
     in the sidebar goes back. The last layout is remembered.
  4. Full dashboard: Servers -> "Test all". Results stream in live. Then
     "Auto: connect best", or click a row and press Connect (double-click connects).

SMARTSCREEN / ANTIVIRUS
  The exe is not code-signed, so Windows may show "Windows protected your PC".
  Click "More info" -> "Run anyway". Some antivirus tools flag any VPN/proxy tool
  heuristically; sing-box.exe is the unmodified official release.
  The UI uses Microsoft Edge WebView2 (preinstalled on Windows 10/11).

MODES
  TUN (default, "route everything")
    Captures ALL apps system-wide (games, Telegram, CLI tools...) - no Proxifier needed.
    With "Tunnel DNS" on (default), DNS is hijacked and resolved by 1.1.1.1
    (DNS-over-HTTPS) THROUGH the tunnel; only the proxy server's own domain is
    resolved with your local DNS. See DNS below.
    LAN / private addresses go direct. Needs administrator.
  Proxy only
    Only the local proxy port below. Optional "System proxy" switch sets the Windows
    proxy (Edge/Chrome/most apps follow it) and restores your old setting on
    disconnect, exit, or on the next start after a crash.

LOCAL PROXY PORT (always on, both modes)
  127.0.0.1:10809  - SOCKS5 and HTTP on the same port (change it in Settings).

DNS (Settings -> Connection -> DNS)
  Tunnel DNS (in-app DNS) ON  (default): apps' DNS lookups are answered with DoH to
    the "Remote DNS" server, carried through the proxy. No DNS leak.
  Tunnel DNS OFF: no DoH and no DNS through the proxy. Apps' lookups go to your normal
    system/ISP resolver directly. Trade-off: your ISP can see (and filter/poison) the
    names you look up. In TUN mode Windows still sends DNS to the virtual adapter, so
    VeePeeEn relays those queries to the system resolver over your real connection.
    The tester also runs without any in-app DNS block when this is off.
  Either way, proxy server domains are resolved with the system DNS.

THE TESTER (Servers -> Test all)
  Fetch    every enabled subscription: direct, then through the current connection,
           then the jsDelivr mirror (raw.githubusercontent.com is often blocked in Iran).
  Stage 1  fast TCP connect pre-filter (256 parallel, 2.5 s). Hysteria2/TUIC (UDP) skip it.
  Stage 2  real proxied test through sing-box, about 24 servers at a time (Settings:
           "Tests in flight"). For each server: 1 cold request to the test URL
           (proxy handshake + TLS included) then 2 warm requests on the same kept-alive
           tunnel. LATENCY = best warm request (comparable to v2rayN's real delay);
           COLD = the first request. Plus a confirm request to cp.cloudflare.com.
           Test URL can be https://www.gstatic.com/generate_204 (default) or
           http://cp.cloudflare.com/generate_204 (cheaper: no TLS).
  Stage 3  exit IP, country and ISP for the best 60 survivors (Settings: "Deep-check").
  Stage 4  "Clean score" 0-100 from ip-api.com, ipapi.is and proxycheck.io, queried
           through each server's own exit. Clean >= 70, Medium 40-69, Dirty < 40.
           Click a row to see every source's flags.
           Note: since Sep 2026 ipapi.is only gives VPN/abuser flags with a (free) API
           key - paste one in Settings to use it as a 3rd scoring source.
  Cancel works at any point. Results, subscriptions and settings are saved in
  %APPDATA%\VeePeeEn.
  The tester shows "This run used ~X MB": subscription downloads + every byte the
  test clients moved + an estimate for proxy/TLS handshakes. A full run over the
  default subscriptions is roughly 20 MB, mostly TLS handshakes of stage 2.

SPEED TEST (never automatic)
  "Test speed" in the toolbar: top 10 / 20 / 30 / custom N of the current sorted and
  filtered list. The menu shows the estimated data first (512 KB per server, ~5 MB for
  10). Runs 2 at a time; click the button again to cancel. A single server: "Test" in
  its Speed cell or "Test speed" in its details panel.

OPENVPN (separate section)
  Full dashboard: "OpenVPN" in the sidebar. Compact view: the "V2Ray / Xray | OpenVPN" switch
  at the top. It has its own server list, sources, tester and connect button; only one
  connection type is active at a time (connecting OpenVPN stops sing-box and restores the
  system proxy, connecting a v2ray server stops OpenVPN).
  Sources (Settings -> OpenVPN, each can be switched off; per-source success stats):
    VPN Gate  official API www.vpngate.net/api/iphone (~1.3 MB). When it is blocked, the
              hourly GitHub mirror GeorgeXie2333/vpngate-list-mirror (raw, then jsDelivr).
              Shows country, operator and VPN Gate's own ping/speed/score/sessions.
    VPNBook   10 servers x TCP 443/80 + UDP 53/25000. The rotating shared password is read
              from vpnbook.com/freevpn/openvpn on every refresh (username "vpnbook").
    Imported  "Import .ovpn" adds your own files (files referenced next to the .ovpn are
              embedded). Profiles that need a login ask for it in their details panel.
  Test all  downloads lists older than 30 min (Settings) and sends every server ONE small
            OpenVPN handshake packet (P_CONTROL_HARD_RESET), 32 at a time, direct. TCP
            servers are TCP-connected first. ~120 bytes per server; no speed tests.
            "Handshake" = round trip from your PC. VG ping/speed are VPN Gate's numbers.
  Connect   runs the bundled openvpn.exe (needs administrator). First connect installs the
            signed tap-windows6 driver and creates a "VeePeeEn TAP" adapter. VPN Gate servers
            use AES-128-CBC, so they always use TAP; Settings can use ovpn-dco (faster) for
            servers with AES-GCM. Tunnel DNS on = DNS through the tunnel + block-outside-dns;
            off = your system DNS. The card shows the exit IP; "Check clean" runs the
            cleanliness check on it (on demand). Configs from the internet are sanitized:
            script/plugin/management/log directives are removed.

SUBSCRIPTION STATS
  After each full test the Subscriptions page shows, per subscription: links, parsed,
  TCP alive, working, success rate (working / parsed) and Clean/Medium/Dirty counts.
  "Best sources" in the tester panel lists the top 3. A server that appears in several
  subscriptions counts for each; the table and details panel show its source(s).

EXPORT
  Export -> "Copy subscription" gives a base64 subscription of all working servers
  (or Clean only) that you can import into v2rayN, Hiddify, NekoBox, v2rayNG...

TROUBLESHOOTING
  * Logs page shows tester, sing-box and openvpn output.
  * OpenVPN "could not create the network adapter": Windows blocked the driver install;
    check Logs. The adapter can be removed later in Device Manager -> Network adapters.
  * "TUN mode needs administrator rights": run VeePeeEn.exe as administrator.
  * Testing while connected in TUN mode is fine: the tester's own traffic bypasses the tunnel.
  * Not supported (skipped and counted): xhttp/splithttp transport, VLESS "encryption"
    (ML-KEM), mKCP - sing-box does not implement them.
